# Vera Merchant AI Assistant — magicpin AI Challenge

A deployment-ready FastAPI implementation of the Vera message engine challenge.

## Endpoints

- `GET /v1/healthz`
- `GET /v1/metadata`
- `POST /v1/context`
- `POST /v1/tick`
- `POST /v1/reply`
- `POST /v1/teardown` (optional)

## Design

The bot is deterministic and stateful. It uses the four context layers supplied by the judge and includes:

- trigger-specific merchant messages
- exact numbers/dates/offers from context
- category-aware offer selection
- customer consent checks
- WhatsApp auto-reply detection and backoff
- immediate action transition after affirmative intent
- off-topic redirection
- suppression-key deduplication
- conversation memory

No merchant/customer payload is sent to a non-LLM external API.

## Local run

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn bot:app --host 0.0.0.0 --port 8080
```

Health check: `http://localhost:8080/v1/healthz`

## Judge simulator

The included `judge_simulator.py` is the challenge-provided simulator. Set its `BOT_URL` to your deployed URL and configure an LLM provider/API key for scoring.

```bash
python judge_simulator.py
```

## Render deployment

This repo contains `render.yaml`. Create a Render web service from this repository and use the generated HTTPS URL. The submission URL is the root URL, e.g. `https://YOUR-SERVICE.onrender.com`, and the judge will call `/v1/*` endpoints.

Set these optional environment variables:

- `TEAM_NAME`
- `TEAM_MEMBERS`
- `CONTACT_EMAIL`

## Submission checklist

- Public HTTPS URL works
- `/v1/healthz` returns 200
- `/v1/metadata` returns team metadata
- `/v1/context` accepts versioned pushes
- `/v1/tick` returns `actions`
- `/v1/reply` returns `send`, `wait`, or `end`
- Local judge simulator produces non-zero scores
