import os, re, time, uuid, math
from datetime import datetime, timezone
from typing import Any, Optional
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title="Vera Merchant AI Assistant", version="1.0.0")
START = time.time()

contexts: dict[tuple[str, str], dict[str, Any]] = {}
conversations: dict[str, dict[str, Any]] = {}
sent_suppressions: set[str] = set()

AUTO_REPLY_PATTERNS = [
    r"thank you for contacting", r"thanks for contacting", r"we will get back",
    r"will get back to you shortly", r"your message has been received",
    r"thank you for reaching out", r"we'll get back", r"will respond shortly"
]


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def norm(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip()


def lower(s: Any) -> str:
    return norm(s).lower()


def is_auto_reply(text: str) -> bool:
    t = lower(text)
    return any(re.search(p, t) for p in AUTO_REPLY_PATTERNS)


def get(scope: str, context_id: Optional[str]) -> Optional[dict[str, Any]]:
    if not context_id:
        return None
    item = contexts.get((scope, context_id))
    return item.get("payload") if item else None


def merchant_for(trigger: dict[str, Any]) -> Optional[dict[str, Any]]:
    return get("merchant", trigger.get("merchant_id"))


def category_for(merchant: dict[str, Any]) -> Optional[dict[str, Any]]:
    return get("category", merchant.get("category_slug"))


def customer_for(trigger: dict[str, Any]) -> Optional[dict[str, Any]]:
    return get("customer", trigger.get("customer_id"))


def active_offer(category: dict[str, Any], merchant: dict[str, Any], keyword: Optional[str] = None) -> Optional[str]:
    offers = merchant.get("offers") or []
    active = [o for o in offers if o.get("status") == "active"]
    if keyword:
        for o in active:
            if keyword.lower() in lower(o.get("title")):
                return o.get("title")
    if active:
        return active[0].get("title")
    catalog = category.get("offer_catalog") or []
    if keyword:
        for o in catalog:
            title = o.get("title", o) if isinstance(o, dict) else str(o)
            if keyword.lower() in lower(title):
                return title
    if catalog:
        o = catalog[0]
        return o.get("title", o) if isinstance(o, dict) else str(o)
    return None


def digest_item(category: dict[str, Any], item_id: str) -> Optional[dict[str, Any]]:
    for item in category.get("digest", []) or []:
        if item.get("id") == item_id:
            return item
    return None


def send_as_for(trigger: dict[str, Any]) -> str:
    return "merchant_on_behalf" if trigger.get("scope") == "customer" or trigger.get("customer_id") else "vera"


def choose_trigger_message(category, merchant, trigger, customer=None):
    kind = trigger.get("kind", "")
    p = trigger.get("payload") or {}
    name = merchant.get("identity", {}).get("owner_first_name") or merchant.get("identity", {}).get("name", "there")
    biz = merchant.get("identity", {}).get("name", "your business")
    perf = merchant.get("performance") or {}
    send_as = send_as_for(trigger)

    # Customer-facing messages: only send when the consent scope supports it.
    if send_as == "merchant_on_behalf":
        c = customer or {}
        consent = c.get("consent", {}).get("scope", [])
        if kind in {"recall_due", "appointment_tomorrow", "chronic_refill_due", "trial_followup"}:
            allowed = any(x in consent for x in ["recall_reminders", "appointment_reminders"])
        else:
            allowed = False
        if not allowed:
            return None, "none", "Customer outreach suppressed because the available consent scope does not cover this message."
        cn = c.get("identity", {}).get("name", "there")
        if kind == "recall_due":
            slots = p.get("available_slots") or []
            slot_text = " or ".join(s.get("label", "") for s in slots[:2])
            body = f"Hi {cn}, a 6-month cleaning is due based on your last visit ({p.get('last_service_date')}). We have {slot_text} available — want me to help confirm one?"
            return body, "open_ended", "Recall is due and the customer is opted in for recall/appointment reminders; use concrete available slots."
        if kind == "trial_followup":
            slots = p.get("next_session_options") or []
            slot_text = slots[0].get("label", "") if slots else "a next session"
            body = f"Hi {cn}, following up on your trial from {p.get('trial_date')}. The next option currently open is {slot_text}. Would you like to take it?"
            return body, "open_ended", "Trial follow-up uses the recorded trial date and an actual next-session option."
        if kind == "chronic_refill_due":
            mols = ", ".join(p.get("molecule_list", [])[:3])
            body = f"Hi {cn}, your refill window is coming up for {mols}. Your saved delivery address is on file. Want the pharmacy team to prepare the refill?"
            return body, "open_ended", "Refill reminder uses only the recorded medicines and saved-address state."
        return None, "none", "No eligible customer-facing template for this trigger."

    # Merchant-facing trigger library.
    if kind == "research_digest":
        item = digest_item(category, p.get("top_item_id", "")) or {}
        title = item.get("title", "a new category research item")
        source = item.get("source", "the latest category digest")
        body = f"Hi {name} — one useful update for {category.get('display_name', category.get('slug','your category'))}: {title}. Source: {source}. Want me to turn this into a short customer-facing post?"
        return body, "open_ended", "Research trigger selected because it is externally sourced, category-specific, and actionable without inventing a claim."
    if kind == "regulation_change":
        item = digest_item(category, p.get("top_item_id", "")) or {}
        deadline = p.get("deadline_iso")
        body = f"Quick heads-up, {name}: {item.get('title','a category compliance update')} (source: {item.get('source','category digest')}). Deadline noted: {deadline}. Want a checklist of the profile/content changes this affects?"
        return body, "open_ended", "Compliance update uses the supplied source and deadline; asks for a concrete next step."
    if kind == "perf_dip":
        metric = p.get("metric", "metric")
        delta = abs(float(p.get("delta_pct", 0))) * 100
        baseline = p.get("vs_baseline")
        body = f"{name}, {metric} are down {delta:.0f}% over the last {p.get('window','7d')} vs the supplied baseline ({baseline}). I can help test one concrete listing change first — want to do that?"
        return body, "yes_stop", "Performance dip is a high-signal internal event; message names the metric, magnitude, window, and baseline."
    if kind == "renewal_due":
        body = f"{name}, your {p.get('plan','current')} plan has {p.get('days_remaining')} days left. Renewal amount in the current account data: ₹{p.get('renewal_amount')}. Want me to walk you through renewal?"
        return body, "yes_stop", "Renewal reminder uses the exact plan, remaining days, and recorded amount."
    if kind == "festival_upcoming":
        festival = p.get("festival", "the upcoming festival")
        body = f"{name}, {festival} is on {p.get('date')}. For a {category.get('slug','local')} business, this is a good window to prep a specific service/offer. Want 2 options based on your current catalog?"
        return body, "yes_stop", "Seasonal trigger is tied to the supplied festival date and category relevance, with no fabricated discount."
    if kind == "wedding_package_followup":
        body = f"{name}, Kavya's wedding is on {p.get('wedding_date')}; the recorded next-step window is the 30-day skin-prep program. Want me to draft that package structure?"
        return body, "yes_stop", "Follow-up advances an already identified customer plan instead of reopening qualification."
    if kind == "curious_ask_due":
        body = f"Quick one for {name}: what service is most in-demand this week is the open question in your Vera cadence. Want a category-specific answer using the latest available signals?"
        return body, "open_ended", "Curiosity trigger is intentionally knowledge-led rather than a generic promotional nudge."
    if kind == "winback_eligible":
        body = f"{name}, since expiry you have {p.get('lapsed_customers_added_since_expiry')} newly lapsed customers, while performance is down {abs(float(p.get('perf_dip_pct',0)))*100:.0f}%. Want to build one win-back message around a specific service rather than a blanket discount?"
        return body, "yes_stop", "Win-back message combines the supplied lapsed-customer count and performance signal and avoids generic percentage-off copy."
    if kind == "ipl_match_today":
        body = f"{name}, DC vs MI is at {p.get('match_time_iso','today')} at {p.get('venue','the listed venue')} in Delhi. If you want a match-day push, I can draft a specific food offer from your current menu."
        return body, "open_ended", "Local event trigger uses the exact match, venue, city, and time supplied."
    if kind == "review_theme_emerged":
        body = f"{name}, {p.get('occurrences_30d')} recent reviews mention '{p.get('theme')}', and the trend is {p.get('trend')}. One review says: \"{p.get('common_quote')}\". Want a response template that addresses the issue directly?"
        return body, "yes_stop", "Review-theme trigger is specific and evidence-backed, using the supplied count, trend, and quote."
    if kind == "milestone_reached":
        body = f"{name}, you're at {p.get('value_now')} reviews — only {p.get('milestone_value') - p.get('value_now',0)} more to reach {p.get('milestone_value')}. Want a simple review-request message for recent happy customers?"
        return body, "open_ended", "Milestone message uses the exact current count and remaining gap."
    if kind == "seasonal_perf_dip":
        body = f"{name}, views are down {abs(float(p.get('delta_pct',0)))*100:.0f}% over {p.get('window','7d')}, and the supplied context marks this as seasonal ({p.get('season_note')}). Rather than panic, want one low-effort acquisition test?"
        return body, "yes_stop", "Message acknowledges the supplied seasonal explanation instead of treating the dip as unexplained failure."
    if kind == "active_planning_intent":
        topic = p.get('intent_topic','the idea you mentioned')
        body = f"{name}, you said you want to explore {topic.replace('_',' ')}. Let's move straight to the draft: I can structure the offer, audience, and CTA now. Want me to draft it?"
        return body, "yes_stop", "Active planning intent is action-ready; the bot advances directly to drafting instead of re-qualifying."
    if kind == "customer_lapsed_hard":
        body = f"{name}, Rashmi has been away for {p.get('days_since_last_visit')} days; her previous focus was {p.get('previous_focus')}. Want a gentle win-back message built around that history?"
        return body, "yes_stop", "Win-back trigger uses only the customer's recorded lapse duration and previous focus."
    if kind == "supply_alert":
        batches = ", ".join(p.get('affected_batches', []))
        body = f"{name}, supply alert: {p.get('molecule')} — affected batches listed are {batches}; manufacturer: {p.get('manufacturer')}. Please verify stock against the alert before dispensing. Want a merchant-facing notice drafted?"
        return body, "yes_stop", "Supply alert surfaces exact molecule, batches, and manufacturer without inventing clinical guidance."
    if kind == "category_seasonal":
        trends = ", ".join(p.get('trends', [])[:3])
        body = f"{name}, the current summer signals include {trends}. The supplied recommendation is to review shelf placement. Want a 3-item shelf action plan?"
        return body, "open_ended", "Seasonal pharmacy trigger uses the supplied demand shifts and recommended shelf action."
    if kind == "gbp_unverified":
        body = f"{name}, your Google Business Profile is currently marked unverified. The supplied verification path is {p.get('verification_path')}; estimated uplift in the dataset is {float(p.get('estimated_uplift_pct',0))*100:.0f}%. Want the verification steps?"
        return body, "yes_stop", "GBP message uses exact verification state, path, and supplied estimate."
    if kind == "cde_opportunity":
        item = digest_item(category, p.get('digest_item_id','')) or {}
        body = f"{name}, there's a CDE/webinar item in your category digest: {item.get('title','see the supplied digest item')}. Credits: {p.get('credits')}; fee: {p.get('fee')}. Want the details?"
        return body, "open_ended", "Opportunity message is tied to the exact digest item and supplied eligibility details."
    if kind == "competitor_opened":
        body = f"{name}, a new nearby competitor, {p.get('competitor_name')}, opened {p.get('distance_km')} km away on {p.get('opened_date')}; their listed offer is {p.get('their_offer')}. Want to strengthen one specific part of your listing without copying them?"
        return body, "yes_stop", "Competitive trigger names the supplied competitor, distance, date, and offer, then proposes a differentiated response."
    if kind == "perf_spike":
        metric = p.get('metric','metric'); delta = float(p.get('delta_pct',0))*100
        body = f"{name}, nice signal: {metric} are up {delta:.0f}% over {p.get('window','7d')} vs baseline {p.get('vs_baseline')}. The supplied likely driver is {p.get('likely_driver')}. Want to turn that into a repeatable post?"
        return body, "open_ended", "Positive performance spike is tied to the supplied metric, baseline, and likely driver."
    if kind == "dormant_with_vera":
        body = f"Hi {name} — it's been {p.get('days_since_last_merchant_message')} days since your last Vera conversation; the last topic was {p.get('last_topic')}. I have one fresh, low-effort idea for {biz}. Want to hear it?"
        return body, "open_ended", "Dormancy message is curiosity-led and grounded in the actual prior topic and elapsed days."
    return f"Hi {name} — I have a useful update for {biz} based on the latest account context. Want to take a look?", "open_ended", "Fallback uses available merchant context without inventing a specific claim."


def template_for(body: str, send_as: str, trigger: dict[str, Any]) -> tuple[str, list[str]]:
    # First outbound must be template-shaped. We keep parameters simple and deterministic.
    if send_as == "merchant_on_behalf":
        return "merchant_customer_outreach_v1", [body[:60]]
    return "vera_contextual_nudge_v1", [trigger.get("merchant_id", "merchant"), trigger.get("kind", "update"), body[:80]]


def record(conversation_id: str, role: str, body: str):
    conversations.setdefault(conversation_id, {"turns": [], "last_trigger": None, "merchant_id": None, "customer_id": None})
    conversations[conversation_id]["turns"].append({"role": role, "body": body, "ts": now_iso()})


def conversation_trigger(conv: dict[str, Any]) -> Optional[dict[str, Any]]:
    return get("trigger", conv.get("last_trigger"))


def reply_compose(req):
    conv = conversations.setdefault(req.conversation_id, {"turns": [], "last_trigger": None, "merchant_id": req.merchant_id, "customer_id": req.customer_id})
    conv["merchant_id"] = req.merchant_id or conv.get("merchant_id")
    conv["customer_id"] = req.customer_id or conv.get("customer_id")
    record(req.conversation_id, req.from_role, req.message)
    text = norm(req.message)
    lt = lower(text)

    # Fast path for canned WhatsApp auto-replies: do not burn turns.
    if is_auto_reply(text):
        count = sum(1 for t in conv["turns"] if t["role"] == req.from_role and is_auto_reply(t["body"]))
        if count >= 2:
            return {"action": "wait", "wait_seconds": 3600, "rationale": "Detected repeated canned WhatsApp auto-reply; suppressing further turns to avoid auto-reply pollution."}
        return {"action": "wait", "wait_seconds": 900, "rationale": "Detected likely canned WhatsApp auto-reply; backing off instead of treating it as merchant intent."}

    # Immediate intent transition: do not ask qualification again.
    affirmative = bool(re.search(r"\b(ok|okay|yes|haan|sure|do it|let'?s do it|go ahead|proceed|start|done)\b", lt))
    if affirmative:
        trig = conversation_trigger(conv)
        if trig and trig.get("kind") == "active_planning_intent":
            merchant = get("merchant", req.merchant_id or conv.get("merchant_id")) or {}
            p = trig.get("payload") or {}
            topic = p.get("intent_topic", "the plan")
            body = f"Perfect — moving to action. I’ll draft the {topic.replace('_',' ')} with the offer structure, target audience, and one clear CTA."
            record(req.conversation_id, "vera", body)
            return {"action":"send","body":body,"cta":"open_ended","rationale":"Merchant explicitly accepted the plan; transitioned directly to action instead of re-qualifying."}
        body = "Perfect — I’ll take that as a yes and move to the next concrete step from the context we have."
        record(req.conversation_id, "vera", body)
        return {"action":"send","body":body,"cta":"open_ended","rationale":"Explicit affirmative detected; advances the conversation rather than repeating the previous question."}

    # Clear opt-out / negative intent.
    if re.search(r"\b(no|nope|not interested|stop|don't|do not|later|not now)\b", lt):
        return {"action":"end","rationale":"Merchant/customer declined; conversation ended without pressure."}

    # Off-topic: stay on mission politely.
    if any(k in lt for k in ["gst", "income tax", "tax filing", "passport", "visa", "loan"]):
        body = "I can help with your merchant listing, offers, campaigns, and customer messaging. For that other request, I don’t want to guess. Shall we continue with the merchant-growth task we were discussing?"
        record(req.conversation_id, "vera", body)
        return {"action":"send","body":body,"cta":"open_ended","rationale":"Politely declines an unrelated request and redirects to Vera’s merchant-growth mission."}

    # If merchant asks for details, use the latest trigger context.
    trig = conversation_trigger(conv)
    merchant = get("merchant", req.merchant_id or conv.get("merchant_id")) or {}
    category = category_for(merchant) or {}
    if trig:
        kind = trig.get("kind", "")
        p = trig.get("payload") or {}
        if "what" in lt and kind == "active_planning_intent":
            topic = p.get("intent_topic", "the plan").replace('_',' ')
            offer = active_offer(category, merchant)
            body = f"For {topic}, I’d start with {offer or 'one concrete service/offer'}, then define the audience and a single CTA. If you want, I can turn that into ready-to-send copy."
            record(req.conversation_id, "vera", body)
            return {"action":"send","body":body,"cta":"open_ended","rationale":"Answers the planning question using the merchant’s current active offer where available."}
        if kind in {"research_digest", "cde_opportunity", "regulation_change"} and any(k in lt for k in ["details", "send", "source", "abstract", "link"]):
            item = digest_item(category, p.get("top_item_id") or p.get("digest_item_id")) or {}
            source = item.get("source", "the supplied category digest")
            body = f"Source: {source}. {item.get('summary','I can share the supplied digest details next.')}"
            record(req.conversation_id, "vera", body)
            return {"action":"send","body":body,"cta":"open_ended","rationale":"Responds with source-backed details already present in the category context."}

    body = "Got it. I’ll keep this focused on the merchant-growth task and use the latest account context rather than asking for information we already have. What would you like to tackle first?"
    record(req.conversation_id, "vera", body)
    return {"action":"send","body":body,"cta":"open_ended","rationale":"Acknowledges the merchant and keeps the conversation moving without inventing missing data."}


class CtxBody(BaseModel):
    scope: str
    context_id: str
    version: int
    payload: dict[str, Any]
    delivered_at: str

class TickBody(BaseModel):
    now: str
    available_triggers: list[str] = Field(default_factory=list)

class ReplyBody(BaseModel):
    conversation_id: str
    merchant_id: Optional[str] = None
    customer_id: Optional[str] = None
    from_role: str
    message: str
    received_at: str
    turn_number: int

@app.get("/v1/healthz")
async def healthz():
    counts = {"category": 0, "merchant": 0, "customer": 0, "trigger": 0}
    for (scope, _), _item in contexts.items():
        counts[scope] = counts.get(scope, 0) + 1
    return {"status":"ok","uptime_seconds":int(time.time()-START),"contexts_loaded":counts}

@app.get("/v1/metadata")
async def metadata():
    return {
        "team_name": os.getenv("TEAM_NAME", "Vera Builders"),
        "team_members": [x.strip() for x in os.getenv("TEAM_MEMBERS", "Candidate").split(",") if x.strip()],
        "model": "deterministic-context-composer-v1",
        "approach": "stateful deterministic composer with trigger-specific templates, consent checks, auto-reply detection and intent-transition handling",
        "contact_email": os.getenv("CONTACT_EMAIL", "candidate@example.com"),
        "version": "1.0.0",
        "submitted_at": now_iso()
    }

@app.post("/v1/context")
async def push_context(body: CtxBody):
    if body.scope not in {"category","merchant","customer","trigger"}:
        return {"accepted":False,"reason":"invalid_scope","details":"scope must be category, merchant, customer, or trigger"}
    key = (body.scope, body.context_id)
    cur = contexts.get(key)
    if cur and cur["version"] >= body.version:
        return {"accepted":False,"reason":"stale_version","current_version":cur["version"]}
    contexts[key] = {"version": body.version, "payload": body.payload, "delivered_at": body.delivered_at}
    return {"accepted":True,"ack_id":f"ack_{body.context_id}_v{body.version}","stored_at":now_iso()}

@app.post("/v1/tick")
async def tick(body: TickBody):
    actions = []
    for trg_id in body.available_triggers:
        trg = get("trigger", trg_id)
        if not trg:
            continue
        merchant = merchant_for(trg)
        category = category_for(merchant) if merchant else None
        customer = customer_for(trg)
        if not merchant or not category:
            continue
        # Never send duplicate trigger messages for the same suppression key.
        suppression = trg.get("suppression_key") or f"trigger:{trg_id}"
        if suppression in sent_suppressions:
            continue
        body_text, cta, rationale = choose_trigger_message(category, merchant, trg, customer)
        if not body_text:
            sent_suppressions.add(suppression)
            continue
        conv_id = f"conv_{merchant.get('merchant_id')}_{trg_id}_{uuid.uuid4().hex[:8]}"
        send_as = send_as_for(trg)
        template_name, template_params = template_for(body_text, send_as, trg)
        conversations[conv_id] = {"turns": [], "last_trigger": trg_id, "merchant_id": merchant.get("merchant_id"), "customer_id": trg.get("customer_id")}
        record(conv_id, "vera", body_text)
        sent_suppressions.add(suppression)
        actions.append({
            "conversation_id": conv_id,
            "merchant_id": merchant.get("merchant_id"),
            "customer_id": trg.get("customer_id"),
            "send_as": send_as,
            "trigger_id": trg_id,
            "template_name": template_name,
            "template_params": template_params,
            "body": body_text,
            "cta": cta,
            "suppression_key": suppression,
            "rationale": rationale
        })
    return {"actions": actions}

@app.post("/v1/reply")
async def reply(body: ReplyBody):
    return reply_compose(body)

@app.post("/v1/teardown")
async def teardown():
    contexts.clear(); conversations.clear(); sent_suppressions.clear()
    return {"ok": True, "cleared": True}
